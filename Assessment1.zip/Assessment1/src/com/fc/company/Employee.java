package com.fc.company;

import com.fc.company.helperclasses.Attendance;
import com.fc.company.helperclasses.Salary;

public class Employee {

//    instance vars
    private int emp_id;
    private String emp_name;
    private String emp_role;

    private Salary emp_sal;
    private float bonus;
    private Attendance emp_attd;

//    constructor
    Employee(int emp_id, String emp_name, String emp_role, Salary emp_sal, Attendance emp_attd) {
        this.emp_id = emp_id;
        this.emp_name = emp_name;
        this.emp_role = emp_role;
        this.emp_sal = emp_sal;
        this.bonus = 0;
        this.emp_attd = emp_attd;
    }


//    getter and setter
    public String getEmp_name() {
        return emp_name;
    }

    public int getEmp_id() {
        return emp_id;
    }

    public Salary getEmp_sal() {
        return emp_sal;
    }

    public String getEmp_role() {
        return emp_role;
    }

    public void setBonus(float bonus) {
        this.bonus = bonus;
    }

    public float getBonus() {
        return bonus;
    }

    public Attendance getEmp_attd() {
        return emp_attd;
    }

    public String toString() {
        return "Employee Name: " + getEmp_name() + "\n" + "Employee Role: " + getEmp_role() + "\n" + "Employee Bonus: " + getBonus() + "\n" + "Employee Attendance: " + getEmp_attd();
    }
}


// setattendance
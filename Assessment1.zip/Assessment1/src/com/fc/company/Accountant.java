package com.fc.company;

import com.fc.company.helperclasses.Attendance;
import com.fc.company.helperclasses.Salary;

public class Accountant extends Employee {

    private String certified_type;

    Accountant(int emp_id, String emp_name, String emp_role, Salary emp_sal, Attendance emp_attendance, String certified_type) {
        super(emp_id, emp_name, emp_role, emp_sal, emp_attendance);
        this.certified_type = certified_type;
    }

    public String getCertified_type() {
        return certified_type;
    }

    public float calcBonus(Employee emp) {
        String role = emp.getEmp_role().toLowerCase();
        int baseSalary = emp.getEmp_sal().getBasic() + emp.getEmp_sal().getHra();
        float bonus = 0;
        switch (role) {
            case "manager":
                bonus = (float) (baseSalary * 0.12);
                break;
            case "admin":
                bonus = (float) (baseSalary * 0.1);
                break;
            case "engineer":
                bonus = (float) (baseSalary * 0.12);
                break;
            case "accountant":
                bonus = (float) (baseSalary * 0.8);
                break;
            default:
                System.out.println("Invalid role");
        }

        return bonus;
    }

    public String toString() {
        return super.toString() + "\n" + "Certified Type: " + certified_type;
    }
}

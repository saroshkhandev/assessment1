package com.fc.company;

import com.fc.company.helperclasses.Attendance;
import com.fc.company.helperclasses.Salary;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Scanner;

public class Admin extends Employee {
    //    init Scanner
    Scanner sc = new Scanner(System.in);
    private String project;
    private ArrayList<Employee> employeeList = new ArrayList<>();

    Admin(int emp_id, String emp_name, String emp_role, Salary emp_sal, String project, Attendance emp_attendance) {
        super(emp_id, emp_name, emp_role, emp_sal, emp_attendance);
        this.project = project;
    }

    public String getProject() {
        return project;
    }


    //    Functions responsible for adding employee
    public void createEmployee() {
        System.out.println("Select Type: ");
        System.out.println("1: Accountant");
        System.out.println("2: Manager");
        System.out.println("3: Engineer");
        int choice = sc.nextInt();
        String role = "";
        switch (choice) {
            case 1 -> role = "accountant";
            case 2 -> role = "manager";
            case 3 -> role = "engineer";
        }
        addEmployee(role);
    }

    public void addEmployee(String role) {
        switch (role) {
            case "engineer" -> {
                Salary emp_sal = initSalary(role);
                Attendance emp_attd = initAttendance();

                System.out.println("Enter Details: ");
                System.out.println("Id: ");
                int id = sc.nextInt();
                sc.nextLine();

                System.out.println("Name: ");
                String emp_name = sc.nextLine();

                System.out.println("Current Project: ");
                String emp_cr_project = sc.nextLine();
                System.out.println("Team: ");
                String emp_team = sc.nextLine();

                Employee Engineer = new Engineer(id, emp_name, role, emp_sal, emp_attd, emp_cr_project, emp_team);
                employeeList.add(Engineer);
            }
            case "manager" -> {
                Salary emp_sal = initSalary(role);
                Attendance emp_attd = initAttendance();

                System.out.println("Enter Details: ");
                System.out.println("Id: ");
                int id = sc.nextInt();
                sc.nextLine();

                System.out.println("Name: ");
                String emp_name = sc.nextLine();

                System.out.println("Branch Name: ");
                String emp_branch = sc.nextLine();

                Employee Manager = new Manager(id, emp_name, role, emp_sal, emp_attd, emp_branch);
                employeeList.add(Manager);
            }

            case "accountant" -> {
                Salary emp_sal = initSalary(role);
                Attendance emp_attd = initAttendance();

                System.out.println("Enter Details: ");
                System.out.println("Id: ");
                int id = sc.nextInt();
                sc.nextLine();

                System.out.println("Name: ");
                String emp_name = sc.nextLine();

                System.out.println("Certified Type: ");
                System.out.println("1: Chartered");
                System.out.println("2: Finance");
                int choice = sc.nextInt();
                String type = "";
                switch (choice) {
                    case 1 -> type = "Chartered";
                    case 2 -> type = "Finance";
                }

                Employee Accountant = new Accountant(id, emp_name, role, emp_sal, emp_attd, type);
                employeeList.add(Accountant);
                System.out.println("Success!");
            }
        }
    }


    public Salary initSalary(String role) {
        int basic = 0, hra = 0, ta = 0;
        switch (role) {
            case "manager" -> {
                basic = 1800000;
                hra = 200000;
                ta = 45000;
            }
            case "accountant" -> {
                basic = 1100000;
                hra = 150000;
                ta = 15000;
            }
            case "engineer" -> {
                basic = 1500000;
                hra = 300000;
                ta = 45000;
            }
        }

        return new Salary(basic, ta, hra);
    }

    public Attendance initAttendance() {
        Date date = new Date();
        SimpleDateFormat sdf1 = new SimpleDateFormat("dd/MM/yy");
        SimpleDateFormat sdf2 = new SimpleDateFormat("hh:mm");
        String str = sdf1.format(date) + " " + sdf2.format(date) + " " + sdf2.format(date);

        ArrayList<String> arr = new ArrayList<>(30);
        arr.add(str);

        return new Attendance(arr);
    }

    public ArrayList<Employee> getEmployeeList() {
        return employeeList;
    }

    //    function to add attendance
    public void makeAttendance(int id) {
        for (Employee emp : employeeList) {
            if (emp.getEmp_id() == id) {
                emp.getEmp_attd().punchIn();
                System.out.println("Success!");
                break;
            }
        }
    }

    public void punchOut(int id) {
        for (Employee emp : employeeList) {
            if (emp.getEmp_id() == id) {
                emp.getEmp_attd().punchOut();
                System.out.println("Success!");
                break;
            }
        }
    }

    public boolean isAccountantPresent() {
        boolean flag = false;
        for (Employee emp : employeeList) {
            if (emp.getEmp_role().equals("accountant")) {
                flag = true;
                break;
            }
        }

        return flag;
    }

    public Employee callAccountant() {
        Employee acc = null;
        for (Employee emp : employeeList) {
            if (emp.getEmp_role().equals("accountant")) {
                acc = emp;
                break;
            }
        }
        return acc;
    }

    public void calcBonus(int id) {
        for (Employee emp : employeeList) {
            if (emp.getEmp_id() == id) {
                Employee accountant = callAccountant();
                float bonus = ((Accountant) accountant).calcBonus(emp);
                emp.setBonus(bonus);
                System.out.println("Success!");
            }
        }
    }

    public void printEmployeeDetails(int id) {
        for (Employee emp : employeeList) {
            if (emp.getEmp_id() == id) {
                System.out.println("__________________________________");
                System.out.println(emp);
                System.out.println("__________________________________");
            }
        }
    }

    public void exportUserData(int id) {
        Path path = Paths.get("C:\\Users\\sarosh.abdullah\\Desktop\\employeedetail.txt");
        String details = "";
        for (Employee emp : employeeList) {
            if (emp.getEmp_id() == id) {
                details = emp.toString();
            }
        }
        BufferedWriter bw = null;
        try {
            File file = new File("C:\\Users\\sarosh.abdullah\\Desktop\\details.txt");
            if (!file.exists()) file.createNewFile();

            FileWriter fw = new FileWriter(file);
            bw = new BufferedWriter(fw);
            bw.write(details);
            System.out.println("Success!");
            System.out.println("File exported to Desktop");
        } catch (IOException e) {
            throw new RuntimeException(e);
        }


    }


    public String toString() {
        return super.toString() + "\n" + "Project Name: " + getProject();
    }
}

package com.fc.company.helperclasses;

public class Salary {
    private int basic;
    private int ta;
    private int hra;

    public Salary(int basic, int ta, int hra) {
        this.basic = basic;
        this.ta = ta;
        this.hra = hra;
//        System.out.println(basic + " " + ta + " " + hra);
    }

    public int getBasic() {
        return basic;
    }

    public int getHra() {
        return hra;
    }

    public int getTa() {
        return ta;
    }
}

package com.fc.company.helperclasses;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

public class Attendance {
    private ArrayList<String> calender;
    private ArrayList<String> presentDaysList;

    private int presentDays;
    private int absentDays;
    private int totalDays;

    public Attendance(ArrayList<String> calender) {
        this.calender = calender;
//        System.out.println(this.calender);
//        System.out.println(this.calender.size());
        calcPresentDays(this.calender);
//        setPresentDaysList(this.calender);
        this.totalDays = this.calender.size();
//        System.out.println(totalDays);
    }


    //    Productivity Functions
    public void calcPresentDays(ArrayList<String> calender) {
        int pdays = 0;
        for (String str : calender) {
            String[] data = str.split(" ");
            if (!data[1].equals("null")) {
                pdays++;
            }
        }

        setPresentDays(pdays);
        setAbsentDays(pdays);
    }

    public void punchIn() {
        Date date = new Date();
        SimpleDateFormat sdf1 = new SimpleDateFormat("dd/MM/yy");
        SimpleDateFormat sdf2 = new SimpleDateFormat("hh:mm");
        String str = sdf1.format(date) + " " + sdf2.format(date) + " ";
        this.calender.add(str);
        calcPresentDays(calender);
    }

    public void punchOut() {
        Date date = new Date();
        SimpleDateFormat sdf = new SimpleDateFormat("hh:mm");
        String str = sdf.format(date);
        int index = calender.size() - 1;
        String data = calender.get(index);
        data = data + str;
        calender.set(index, data);
    }

    //    Getter Setters
    public ArrayList<String> getPresentDaysList() {
        return presentDaysList;
    }

//    public void setPresentDaysList(ArrayList<String> calender) {
//        for (String str : calender) {
//            String[] data = str.split(" ");
//            if (!data[1].equals("null")) {
////                System.out.println(data[0]);
////                presentDaysList.add(data[0]);
//            }
////            System.out.println();
//        }
//    }

    public int getPresentDays() {
        return presentDays;
    }

    public void setPresentDays(int presentDays) {
        this.presentDays = presentDays;
    }

    public int getAbsentDays() {
        return absentDays;
    }

    public void setAbsentDays(int presentDays) {
        this.absentDays = calender.size() - presentDays;
    }

    public int getTotalDays() {
        return totalDays;
    }

    public String toString() {
        return "\nTotal Days: " + getTotalDays() + "\n" + "Present Days: " + getPresentDays() + "\n" + "Absent Days: " + getAbsentDays();
    }
}

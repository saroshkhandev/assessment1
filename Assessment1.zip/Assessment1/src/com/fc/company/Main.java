package com.fc.company;

import com.fc.company.helperclasses.Attendance;
import com.fc.company.helperclasses.Salary;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Scanner;

public class Main {
    static Scanner sc = new Scanner(System.in);

    public static void main(String[] args) {
        // Main Method Init

        ArrayList<String> admDates = new ArrayList<>();
        admDates.add("1/2/23 null null");
        admDates.add("2/2/23 null null");
        admDates.add("3/2/23 11.10am 6:15pm");
        admDates.add("4/2/23 10.05am 6:15pm");
        admDates.add("5/2/23 9.05am 6.15pm");
        admDates.add("6/2/23 11.50am 6.15pm");
        admDates.add("7/2/23 11.00am 6.15pm");

        //        Admin
        Salary adm_sal = new Salary(250000, 100000, 150000);
        Attendance adm_attd = new Attendance(admDates);
        Employee admin = new Admin(1001, "Micheal", "Admin", adm_sal, "CloudApp", adm_attd);

        boolean status = false;
        System.out.println("Dummy account details-> id: 1001 - password: pass1");
        System.out.println("Enter Admin id: ");
        int adminId = sc.nextInt();
        sc.nextLine();
        System.out.println("Enter Password: ");
        String pass = sc.nextLine();

        if(adminId == admin.getEmp_id() && pass.equals("pass1")) status = true;


        while (status) {
            System.out.println("Welcome " + admin.getEmp_name());
            System.out.println("ADMIN PANEL");
            System.out.println();
            System.out.println("Choose any option: ");
            System.out.println("1: Add an Employee");
            System.out.println("2: Mark Attendance");
            System.out.println("3: Punch Out");
            System.out.println("4: Calculate Bonus");
            System.out.println("5: Print Employee Details");
            System.out.println("6: Export Employee Details");
            System.out.println("9: To Exit");
            System.out.println("____________________________");
            int choice = sc.nextInt();

            switch (choice) {
                case 1 -> {
                    ((Admin) admin).createEmployee();
                }
                case 2 -> {
                    System.out.println("Enter Employee id: ");
                    int id = sc.nextInt();
                    ((Admin) admin).makeAttendance(id);
                }
                case 3 -> {
                    System.out.println("Enter Employee id: ");
                    int id = sc.nextInt();
                    ((Admin) admin).punchOut(id);
                }

                case 4 -> {
                    System.out.println("Checking Accountant: ");
                    if(((Admin) admin).isAccountantPresent()) {
                        System.out.println("Enter Employee id: ");
                        int id = sc.nextInt();
                        ((Admin) admin).calcBonus(id);
                    } else {
                        System.out.println("No Accountant Found: Add accountant first.");
                    }
                }

                case 5 -> {
                    System.out.println("Enter Employee id: ");
                    int id = sc.nextInt();
                    ((Admin) admin).printEmployeeDetails(id);
                }

                case 6 -> {
                    System.out.println("Enter Employee id: ");
                    int id = sc.nextInt();
                    ((Admin) admin).exportUserData(id);
                }

                case 9 -> System.exit(1);
            }

            System.out.println("Do you want to continue (Y/N)");
            char ch = sc.next().charAt(0);
            ch = Character.toLowerCase(ch);
            status = ch == 'y';
        }


    }


    public static void printBonus(Employee emp) {
        System.out.println("------------------------------");
        System.out.println("Emp id: " + emp.getEmp_id());
        System.out.println("Name: " + emp.getEmp_name());
        System.out.println("Bonus: " + emp.getBonus());
        System.out.println("------------------------------");
    }
}
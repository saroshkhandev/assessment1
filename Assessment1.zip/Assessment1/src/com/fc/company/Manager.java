package com.fc.company;

import com.fc.company.helperclasses.Attendance;
import com.fc.company.helperclasses.Salary;

public class Manager extends Employee{

    private String mr_branch;

//    init super class and current class
    Manager(int emp_id, String emp_name, String emp_role, Salary emp_sal, Attendance emp_attendance, String mr_branch) {
        super(emp_id, emp_name, emp_role, emp_sal, emp_attendance);
        this.mr_branch = mr_branch;
    }

    public String getMr_branch() {
        return mr_branch;
    }

    public String toString() {
        return super.toString() + "\n" + "Branch Name: " + getMr_branch();
    }
}

package com.fc.company;

import com.fc.company.helperclasses.Attendance;
import com.fc.company.helperclasses.Salary;

public class Engineer extends Employee {

    private String currentProject;
    private String team;

    Engineer(int emp_id, String emp_name, String emp_role, Salary emp_sal, Attendance emp_attendance, String currentProject, String team) {
        super(emp_id, emp_name, emp_role, emp_sal, emp_attendance);
        this.currentProject = currentProject;
        this.team = team;
    }

    public String getCurrentProject() {
        return currentProject;
    }

    public String getTeam() {
        return team;
    }

    public String toString() {
        return super.toString() + "\n" + "Current Project: " + getCurrentProject() + "\n" + "Team: " + getTeam();
    }
}
